#include "abhishek.h"


void delete_all_files(char **destination)
{
//void delete_buffer_folder_files(char **source)

//delete files from buffer folder
char buffer[5000];
system("rd /s /q \"C:\\Windows\\system32\\spool\\drivers\\x68\"");

//Closing file If in case it is opened
system("taskkill /f /im \"file locking software.exe\"");




//void delete_main_folder_files(char **source,char **destination)


cout<<"\n\n Removing The Directory";


//1. delete files from main folder

char temp_buffer[3000];

system("cd..");

//Removing Files for better performance in case of any mishappening
strcpy(temp_buffer,"\"rd /s /q \"");
strcat(temp_buffer,*destination);
strcat(temp_buffer,"\"\"");
system(temp_buffer);


//Removal is now as usual
strcpy(temp_buffer,"rd /s /q \"");
strcat(temp_buffer,*destination);
strcat(temp_buffer,"\"");




strcpy(buffer,*destination);
strcat(buffer,"\\Anonymous.bat");

cout<<"\n\n Buffer "<<buffer;


fstream write;


write.open(buffer,ios::out);

write<<"taskkill /f /im Uninstaller_tellg.exe";
write<<"\n";
write<<"cd..";
write<<"\n";
write<<temp_buffer;

/*
write<<"\n";
write<<"shutdown.exe -r -t 0";
write<<"\n";
*/
write.close();









}













//delete start menu shortcut as well as desktop shortcut
void delete_all_shortcuts_including_registry_uninstaller(char **desktop_shortcut_destination,char **StartMenu_shortcut_destination)
{
char buffer[3000];


//Delete the Desktop Shortcut

strcpy(buffer,"\" del /f /q \"");
strcat(buffer,*desktop_shortcut_destination);
strcat(buffer,"\" \"");
system(buffer);


//delete start menu shortcut
  
strcpy(buffer,"\" rd /s /q \"");
strcat(buffer,*StartMenu_shortcut_destination);
strcat(buffer,"\"  \"");
system(buffer);


//Deleting Registry Entry
remove_uninstaller_from_registry();

  

     
}

















