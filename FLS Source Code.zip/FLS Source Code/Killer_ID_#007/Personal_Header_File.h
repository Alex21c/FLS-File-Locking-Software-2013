#define PERSONAL_HEADER_FILE_H



//Functions Regarded to Registry
void remove_uninstaller_from_registry();




//Functions Related to clearing Files
void  delete_all_files(char **destination);


//Function related to uninstallation
void delete_all_shortcuts_including_registry_uninstaller(char **desktop_shortcut_destination,char **StartMenu_shortcut_destination);



