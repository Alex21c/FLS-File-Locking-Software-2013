#include "abhishek.h"


int main(int argc,char *argv[])
{

if(argc>1)
{    
if(strcmp(argv[1],"Remove_Uninstaller_From_Registry")==0)  
{
//cout<<"Executed";  
//system("pause");
                                                          
remove_uninstaller_from_registry();
}



else if(strcmp(argv[2],"Delete All files")==0)    
{
//cout<<"Executed";                                                            
//system("pause");
delete_all_files(&argv[1]);   //file locking software installation destinaiton 
}




else if(strcmp(argv[3],"delete_all_shortcuts_including_registry_uninstaller")==0)    
{
delete_all_shortcuts_including_registry_uninstaller(&argv[1],&argv[2]);//desktop_shortcut_path ,start menu shorcut path
} 











}

//getch();


return 0;    
}
