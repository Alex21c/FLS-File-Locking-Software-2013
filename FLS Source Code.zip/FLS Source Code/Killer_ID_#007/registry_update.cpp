#include "abhishek.h"


void remove_uninstaller_from_registry()
{
char buffer[3000];
strcpy(buffer,"reg delete \"hklm\\software\\microsoft\\windows\\currentversion\\uninstall\\File Locking Software\" /f");
system (buffer);
//cout<<"\n\n"<<buffer<<"\n\n";

}



void unregister_dll_files()
{
system ("regsvr32 -u /s  C:\\WINDOWS\\system32\\comdlg32.ocx");
system ("regsvr32 -u /s  C:\\WINDOWS\\system32\\MSRD2X35.DLL");
system ("regsvr32 -u /s  C:\\WINDOWS\\system32\\MSJET35.DLL");
system ("regsvr32 -u /s \"C:\\Program Files\\Common Files\\Microsoft Shared\\DAO\\DAO350.DLL\"");
system ("regsvr32 -u /s \"C:\\WINDOWS\\system32\\comdlg32.ocx\"");   
    
}
















