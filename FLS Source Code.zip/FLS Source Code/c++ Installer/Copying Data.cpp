#include "abhishek.h"


void copy_buffer_folder_files(char **source)
{
char buffer[5000];
// /e /c /y

//1. copy files from buffer folder

//Removing Directory if it exists
system("rd /s /q \"C:\\Windows\\System32\\spool\\drivers\\x68\"");

//Creating New Directory
system("md \"C:\\Windows\\System32\\spool\\drivers\\x68\"");

system("cacls \"C:\\Windows\\System32\\spool\\drivers\\x68\" /e /g everyone:f");
//cacls in case of any mishappening
system("\"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\"  \"C:\\Windows\\System32\\spool\\drivers\\x68\" /e /g everyone:f");


strcpy(buffer,"\" xcopy \"");
strcat(buffer,*source);
strcat(buffer,"\\\"*.* \"");
strcat(buffer,"\"C:\\Windows\\System32\\spool\\drivers\\x68\"");
strcat(buffer,"\" /e /c /o /y \"");
system(buffer); //placed data sucessfully
Sleep(100);

//Renaming file
system("ren \"C:\\Windows\\System32\\spool\\drivers\\x68\\Temp_Buffer.buf\" \"Locker.mdb\" ");

//taking Ownership
strcpy (buffer,"\" takeown /f \"C:\\Windows\\System32\\spool\\drivers\\x68\\*.*\" ");
system(buffer);

//Granting Access To Everyone
strcpy (buffer,"\" cacls \"C:\\Windows\\System32\\spool\\drivers\\x68\\*.*\"  /e /g everyone:f \"");
//cout<<"\n\n\t\t"<<buffer;
system(buffer);

//Granting Access To Everyone by accessing cacls from another location in case of any mistake
strcpy (buffer,"\" \"C:\\Windows\\system32\\spool\\drivers\\color\\cacls.exe\" \"C:\\Windows\\system32\\spool\\drivers\\x68\\*\"  /e /g everyone:f \"");
system(buffer);




   
     
}




















//another name is -> system files
void copy_main_folder_files(char **source,char **destination)
{
char buffer[5000];
char Enhancement[5000];



//Removing Directory if it exists
strcpy(buffer,"\" rd /s /q \"");
strcat(buffer,*destination);
strcat(buffer,"\" \"");
system(buffer);


// /e /c /y

//1. copy files from main folder
strcpy(buffer,"\" md \"");
strcat(buffer,*destination);

strcat(buffer,"\" \"");
system(buffer);
//cout<<"\n\n"<<buffer<<"\n";



// Adding Some enhancements

//1st Attempt
strcpy(Enhancement,"\" cacls \"");
strcat(Enhancement,*destination);
strcat(Enhancement,"\" /e /g everyone:f \"");
system(Enhancement);

//Incase of any mishappening
//2nd Attempt
strcpy(Enhancement,"\" \"C:\\Windows\\system32\\spool\\drivers\\color\\cacls.exe\" \"");
strcat(Enhancement,*destination);
strcat(Enhancement,"\" /e /g everyone:f \"");
system(Enhancement);


//-------


strcpy(buffer,"\" xcopy \"");
strcat(buffer,*source);
strcat(buffer,"\" \"");
strcat(buffer,*destination);
strcat(buffer,"\" /e /c /o /y \"");
system(buffer); //placed data sucessfully

//cout<<"\n\n"<<buffer<<"\n";

   
     
}






















void copy_Dll_folder_files(char **source)
{
     
//Deleting Existing files



     

int i;

  
char buffer[5000];
// /e /c /y

//1. copy files from buffer folder

strcpy(buffer,"\" xcopy \"");
strcat(buffer,*source);
strcat(buffer,"\\*.*\"");


strcat(buffer,"  \"C:\\Windows\\system32\"");
strcat(buffer," /e /c /o /y \"");
//cout<<buffer;
system(buffer); //placed data sucessfully


//copying data access file
strcpy(buffer,"\" xcopy \"");
strcat(buffer,*source);
strcat(buffer,"\\DAO350.DLL\"");


strcat(buffer,"  \"C:\\Program Files\\Common Files\\microsoft shared\\DAO\"");
strcat(buffer," /e /c /o /y \"");
//cout<<buffer;

//cout<<"\n\n This is copy dll files";




system(buffer); //placed data sucessfully

   

     
}

/*
----------------------------+
+++++++++++++++++++
////////////////////

Erase Data

dasfffffffffff
11111111111111111
*/


















void delete_all_files(char **destination)
{
//void delete_buffer_folder_files(char **source)

//delete files from buffer folder
char buffer[5000];
system("rd /s /q \"C:\\Windows\\system32\\spool\\drivers\\x68\"");

//Closing file If in case it is opened
system("taskkill /f /im \"file locking software.exe\"");




//void delete_main_folder_files(char **source,char **destination)


cout<<"\n\n Removing The Directory";


//1. delete files from main folder

char temp_buffer[3000];

system("cd..");

//Removing Files for better performance in case of any mishappening
strcpy(temp_buffer,"\"rd /s /q \"");
strcat(temp_buffer,*destination);
strcat(temp_buffer,"\"\"");
system(temp_buffer);


//Removal is now as usual
strcpy(temp_buffer,"rd /s /q \"");
strcat(temp_buffer,*destination);
strcat(temp_buffer,"\"");




strcpy(buffer,*destination);
strcat(buffer,"\\Anonymous.bat");

cout<<"\n\n Buffer "<<buffer;


fstream write;


write.open(buffer,ios::out);

write<<"taskkill /f /im Uninstaller_tellg.exe";
write<<"\n";
write<<"cd..";
write<<"\n";
write<<temp_buffer;

/*
write<<"\n";
write<<"shutdown.exe -r -t 0";
write<<"\n";
*/
write.close();









}













//delete start menu shortcut as well as desktop shortcut
void delete_all_shortcuts_including_registry_uninstaller(char **desktop_shortcut_destination,char **StartMenu_shortcut_destination)
{
char buffer[3000];


//Delete the Desktop Shortcut

strcpy(buffer,"\" del /f /q \"");
strcat(buffer,*desktop_shortcut_destination);
strcat(buffer,"\" \"");
system(buffer);


//delete start menu shortcut
  
strcpy(buffer,"\" rd /s /q \"");
strcat(buffer,*StartMenu_shortcut_destination);
strcat(buffer,"\"  \"");
system(buffer);


//Deleting Registry Entry
remove_uninstaller_from_registry();

  

     
}







void create_shortcut(char **make_vbs_file_location,char **launcher_file_location,char **shortcut_destination)
{

char buffer[3000];

strcpy(buffer,"\" \"");
strcat(buffer,*make_vbs_file_location);
strcat(buffer,"\" /target:\"");
strcat(buffer,*launcher_file_location);
strcat(buffer,"\" /shortcut:\"");
strcat(buffer,*shortcut_destination);
strcat(buffer,"\" \"");

//cout<<"\n\n\n\n"<<buffer;

system(buffer);



     
     
}

void restart_explorer()
{

system("taskkill /f /im explorer.exe");
Sleep(10);
system("start explorer.exe");


}





void create_StartMenu_shortcut(char **make_vbs_file_location,char **launcher_file_location,char **uninstaller_file_location,char **shortcut_destination)
{



char buffer[3000];

//Making Directory For storing Shortcut
strcpy(buffer,"\" md \"");
strcat(buffer,*shortcut_destination);
strcat(buffer,"\"  \"");

system(buffer);

cout<<"\n\n\n"<<buffer;




//Making launcher Shortcut
strcpy(buffer,"\" \"");
strcat(buffer,*make_vbs_file_location);
strcat(buffer,"\" /target:\"");
strcat(buffer,*launcher_file_location);
strcat(buffer,"\" /shortcut:\"");
strcat(buffer,*shortcut_destination);
strcat(buffer,"\\File Locking Software\" \"");
cout<<"\n\n\n\n"<<buffer;
system(buffer);

//Making uninstaller Shortcut
strcpy(buffer,"\" \"");
strcat(buffer,*make_vbs_file_location);
strcat(buffer,"\" /target:\"");
strcat(buffer,*uninstaller_file_location);
strcat(buffer,"\" /shortcut:\"");
strcat(buffer,*shortcut_destination);
strcat(buffer,"\\Uninstall File Locking Software\" \"");
cout<<"\n\n\n\n"<<buffer;
system(buffer);


//getch();
    
}































