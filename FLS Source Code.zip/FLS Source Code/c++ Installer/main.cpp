#include "abhishek.h"


int main(int argc,char *argv[])
{

if(argc>1)
{    
if(strcmp(argv[1],"Remove_Uninstaller_From_Registry")==0)  
{
//cout<<"Executed";  
//system("pause");
                                                          
remove_uninstaller_from_registry();
}

else if(strcmp(argv[1],"Restart The Explorer")==0)    
{
//cout<<"Executed";                                                            
//system("pause");
restart_explorer();
}
else if(strcmp(argv[1],"Register Dll Files")==0)    
{
//cout<<"Executed";                                                            
//system("pause");
register_dll_files();
}
else if(strcmp(argv[1],"UnRegister Dll Files")==0)    
{
//cout<<"Executed";                                                            
//system("pause");
unregister_dll_files();
}

else if(strcmp(argv[2],"Copy Files from Buffer Folder")==0)    
{
//cout<<"Executed";                                                            
//system("pause");
copy_buffer_folder_files(&argv[1]);//take source from where files are being to be copied
}

else if(strcmp(argv[2],"Copy Files From Dll Folder")==0)    
{
//cout<<"Executed";                                                            
//system("pause");
copy_Dll_folder_files(&argv[1]); //take source from where files are being to be copied
}

else if(strcmp(argv[2],"Delete All files")==0)    
{
//cout<<"Executed";                                                            
//system("pause");
delete_all_files(&argv[1]);   //file locking software installation destinaiton 
}



else if(strcmp(argv[3],"Copy files From Main Folder")==0)    
{
//cout<<"Executed";                                                            
//system("pause");
copy_main_folder_files(&argv[1],&argv[2]);//source ,destination
}  


else if(strcmp(argv[3],"delete_all_shortcuts_including_registry_uninstaller")==0)    
{
delete_all_shortcuts_including_registry_uninstaller(&argv[1],&argv[2]);//desktop_shortcut_path ,start menu shorcut path
} 




else if(strcmp(argv[3],"Add_Uninstaller_To_Registry")==0)    
{
//cout<<"Executed";                                                            
//system("pause");
add_uninstaller_to_registry(&argv[1],&argv[2]); //launcher file , kill file
}
else if(strcmp(argv[4],"Create Shortcut")==0)    
{
//cout<<"Executed";                                                            
//system("pause");
create_shortcut(&argv[1],&argv[2],&argv[3]); //vbs_make_file_path,launcher_file_path,root_directory
}
else if(strcmp(argv[4],"Install Fonts")==0)    
{
install_fonts(&argv[1],&argv[2],&argv[3]); //font source ,registry_value,registry_data
}
else if(strcmp(argv[5],"Create StartMenu Shortcut")==0)    
{
create_StartMenu_shortcut(&argv[1],&argv[2],&argv[3],&argv[4]); //vbs_make_file_path,launcher_file_path,root_directory
}


//getch();







}

//getch();


return 0;    
}
