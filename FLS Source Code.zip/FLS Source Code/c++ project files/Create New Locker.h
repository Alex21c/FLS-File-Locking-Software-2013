#define ENCRYPTION_H

 void Delete_Existing_File(char **file_name);
void create_locker(char **file_name);
