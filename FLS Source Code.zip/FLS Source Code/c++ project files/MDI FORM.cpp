#include "abhishek.h"


void create_password_reset_file(char **user_name,char **password,char **destination)
{

char file_path[3000];
char buffer[3000];
fstream read,write;

int key=219;
int i;


strcpy(file_path,*destination);
strcat(file_path,"\\Reset file.FLS");

//Encrypting User Name
strcpy(buffer,*user_name);
for (i=0;i<strlen(buffer);i++)
{
buffer[i]=buffer[i]^key;
}
strcpy(*user_name,buffer);

//Encrypting Password
strcpy(buffer,*password);
for (i=0;i<strlen(buffer);i++)
{
buffer[i]=buffer[i]^key;
}
strcpy(*password,buffer);


write.open(file_path,ios::out);
write<<*user_name;
write<<"\n";
write<<*password;




write.close();





}




void access_password_reset_file(char **user_name,char **password,char **destination,char **temp_file_location)
{

char file_path[3000];
char buffer[3000];

char temp_user_name[3000],temp_password[3000];
fstream read,write;

int key=219;
int i;



//Obtain path with file name
strcpy(file_path,*destination);



//open file
read.open(file_path,ios::in);
read.getline(temp_user_name,2900,'\n');
read.getline(temp_password,2900,'\n');
read.close();


//Encrypting User Name
strcpy(buffer,temp_user_name);
for (i=0;i<strlen(buffer);i++)
{
buffer[i]=buffer[i]^key;
}
strcpy(temp_user_name,buffer);

//Encrypting Password
strcpy(buffer,temp_password);
for (i=0;i<strlen(buffer);i++)
{
buffer[i]=buffer[i]^key;
}
strcpy(temp_password,buffer);

write.open (*temp_file_location,ios::out);

cout<<"\n Temp User_name = "<<temp_user_name<<"\tActual User_name = "<<*user_name<<"\n Temp Password = "<<temp_password<<"\tActual Password =    "<<*password;
if((strcmp(temp_user_name,*user_name)==0)&&(strcmp(temp_password,*password)==0))
{
cout<<"Access Granted"; //98
write<<"Access Granted";
}
else
{
cout<<"Error"; //87
write<<"Error";
}
write.close();



}
