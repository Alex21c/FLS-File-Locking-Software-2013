
#include "abhishek.h"


int main(int argc,char *argv[])
{

  
if(argc>1)
{
if(strcmp(argv[2],"Delete Existing File")==0)
{

                    
Delete_Existing_File(&argv[1]);  
}



}   

return 0;
}











