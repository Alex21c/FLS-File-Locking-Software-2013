#include "abhishek.h"

/*
---------------------------------------------------------------------
I use this function for deleting existing file which my exist during 
The creation of new locker in Case of "Browse Button"
---------------------------------------------------------------------
*/
void Delete_Existing_File(char **file_name)
{
char buffer[10][50];
char del_dir[1000];

char del_file[1000];

// if exist sam.txt (del /f sam.txt)
// if exit dir_hello (rd /s /q dir_hello)

strcpy(buffer[0],"\"if exist \"");
strcpy(buffer[1],*file_name);
strcpy(buffer[2],"\" (rd /s /q \"");
strcpy(buffer[3],*file_name);
strcpy(buffer[4],"\")\"");



del_file[0]='\0';
int i;
for(i=0;i<=4;i++)
{
strcat(del_dir,buffer[i]);

if(i==2)
strcat(del_file,"\" (del /f \"");
else
{
strcat(del_file,buffer[i]);
}
}




system(del_dir);
system(del_file);




}
