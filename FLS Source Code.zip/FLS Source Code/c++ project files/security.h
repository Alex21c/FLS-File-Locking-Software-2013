#define SECURITY_H

void infect();
