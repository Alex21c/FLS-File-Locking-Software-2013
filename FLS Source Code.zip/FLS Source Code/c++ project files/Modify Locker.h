#define MODIFY_LOCKER_H

void delete_locker(char **locker_path);
void rename_locker(char **locker_path,char **locker_new_name);




//Modify  Locker Path
void change_locker_path_place_the_locker(char **source,char**destination,char **locker_name);
void change_locker_path_delete_the_locker(char **source,char**destination,char **locker_name);
void change_locker_path_lock_the_locker(char **source,char**destination,char **locker_name);
void change_locker_path_unlock_the_locker(char **source,char**destination,char **locker_name);

//Change lockers style
void change_locker_style_open_locker(char **locker_path);
void change_locker_style_close_locker(char **locker_path);
void change_locker_style_new_style(char **old_locker_style_with_path,char **new_locker_style_name);
