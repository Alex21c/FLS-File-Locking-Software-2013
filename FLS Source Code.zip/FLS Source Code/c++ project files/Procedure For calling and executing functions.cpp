/*
-------------------------------------------------------------------
calling "Create New Folder" Related functions
------------------------------------------------------------------


_____________________________________________________________________________

-------------
1. Calling:    void Delete_Existing_File(char **file_name) 
-------------           
                   

Syntax:
        ".exe file name" "file to be deleted along with path" "Delete Existing File"
_____________________________________________________________________________
        

_____________________________________________________________________________

-------------
2. Calling:    create_locker(&argv[1]);
-------------           
                   

Syntax:
        ".exe file name" "locker name" "Create New Locker"
_____________________________________________________________________________


_____________________________________________________________________________

-------------
3. Calling:    encrypt_or_decrypt(&argv[1]);
-------------           
                   

Syntax:
        ".exe file name" "file name to be encrypted or decrypted" "Encrypt or Decrypt"
_____________________________________________________________________________


_____________________________________________________________________________

-------------
4. Calling:    copy_files_inside_the_temp_folder(&argv[1],&argv[2]);
-------------           
                   

Syntax:
        ".exe file name" "file to be copied" "destination i.e temp folder path where file is to be copied" "Copy Files Inside the Temp folder"
_____________________________________________________________________________



-------------------------------------------------------------------
*/


