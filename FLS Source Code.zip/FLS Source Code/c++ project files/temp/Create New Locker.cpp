#include "abhishek.h"


void create_locker(char **file_name)
{
     
     char cmd_command[2000]="md \"";
     
     char secure_locker[2000]="cacls \"";
     
     
     strcat(secure_locker,*file_name);
          
     
     strcat(secure_locker,"\" /e /c /d everyone");
     
     
     strcat(cmd_command,*file_name);
     
     strcat(cmd_command,"\"");
     
     system(cmd_command);
     
    system(secure_locker);
     
     //Locking Locker UP
     
     
    
     
     
     
     
}




/*
---------------------------------------------------------------------
I use this function for deleting existing file which my exist during 
The creation of new locker in Case of "Browse Button"
---------------------------------------------------------------------
*/
void Delete_Existing_File(char **file_name)
{


     

char buffer[10][1000];
char del_dir[1000];

char del_file[1000];
char tfile_name[1000];




strcpy(tfile_name,*file_name);


// if exist sam.txt (del /f sam.txt)
// if exit dir_hello (rd /s /q dir_hello)

strcpy(buffer[0],"\"if exist \"");
strcpy(buffer[1],tfile_name);
strcpy(buffer[2],"\" (rd /s /q \"");
strcpy(buffer[3],tfile_name);
strcpy(buffer[4],"\")\"");



fflush(stdin);
int i;
for(i=0;i<=4;i++)
{
strcat(del_dir,buffer[i]);

if(i==2)
strcat(del_file,"\" (del /f \"");
else
{
strcat(del_file,buffer[i]);
}


}










system(del_dir);
system(del_file);




}
