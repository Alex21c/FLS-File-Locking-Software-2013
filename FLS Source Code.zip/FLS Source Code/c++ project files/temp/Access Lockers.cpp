#include "abhishek.h"


void encrypt_or_decrypt(char **file_name)
{

fstream read_file,write_file;

char *buffer;
long int size;




read_file.open(*file_name,ios::in|ios::binary|ios::ate);


size=read_file.tellg();
read_file.seekg(ios::beg);

buffer =new char [size];



read_file.read(buffer,size);
read_file.close();


//modify the buffer data
int len=strlen(buffer);
int i,key=217;
//Encrypt or Decrypt buffer data




for(i=0;i<len;i++)
{


buffer[i]=buffer[i]^key;

}




write_file.open(*file_name,ios::out|ios::binary);
write_file.write(buffer,size);
write_file.close();


delete buffer;





}









/***************************************************************************/









void copy_files_inside_the_temp_folder(char **file_name,char **temp_folder_path)
{
   
   
   //takeown /f filename
   char takeown[2000]="\" takeown /f \"";
   strcat(takeown,*file_name);
   strcat(takeown,"\" \"");
   
   /*
   copy /y  source,destination
   /y -> overwrite confimation prompt of being files overwritten
   */
   char copy[2000]="\" copy /y \"";
   strcat(copy,*file_name);//source
   strcat(copy,"\" \"");
   strcat(copy,*temp_folder_path);//destination
   strcat(copy,"\" \"");
   
   // del /f /q file_name
   
   char del[2000]="\"del /f /q \"";
   strcat(del,*file_name);
   strcat(del,"\" \"");
   
  
   system(takeown);
   
   
   system(copy);
   
   system(del);
 
     
     
     
}






/***************************************************************************/







void open_the_locker_folder(char **locker_formal_path,char **locker_informal_path)
{
/*
----------------unlocking the locker i.e. changing access controls---------------

syntax:       
cacls file_name /e /g everyone:f

cacls "*locker_formal_path" /e /g everyone:f 

*/

char unlock_locker[2000];
char buffer[2000]="\" cacls \"";
strcat(buffer,*locker_informal_path);
strcat(buffer,"\" /e /g everyone:f \"");


strcpy(unlock_locker,buffer);

//cout<<"\n\n"<<unlock_locker;
system(unlock_locker);


char rename_locker[2000];



//ren "*locker_informal_path" "*locker_formal_path"

/*
----------------changing the locker type to the formal locker type i.e renaming---------------

syntax:       
ren locker_file_name_with_extensoin locker_file_name_without_extensoin 
*/

strcpy(buffer,"\" ren \"");
strcat(buffer,*locker_informal_path);
strcat(buffer,"\" \"");
strcat(buffer,*locker_formal_path);
strcat(buffer,"\" \"");

strcpy(rename_locker,buffer);
//cout<<"\n\n"<<rename_locker;
system(rename_locker);


     

}

/*

``````````````````````````````````````````````````````````````````````````````````~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

void close_the_locker_folder(char **locker_formal_path,char **locker_informal_path)
{
     

char buffer[2000];
char rename_locker[2000];



//ren "*locker_informal_path" "*locker_formal_path"

/*
----------------changing the locker type to the formal locker type i.e renaming---------------

syntax:       
ren locker_file_name_with_extensoin locker_file_name_without_extensoin 
*/

strcpy(buffer,"\" ren \"");
strcat(buffer,*locker_formal_path);
strcat(buffer,"\" \"");
strcat(buffer,*locker_informal_path);
strcat(buffer,"\" \"");

strcpy(rename_locker,buffer);
//cout<<"\n\n"<<rename_locker;
system(rename_locker);





/*
----------------locking the locker i.e. changing access controls---------------

syntax:       
cacls file_name /e /g everyone:f

cacls "*locker_formal_path" /d everyone 

*/

char lock_locker[2000];
strcpy(buffer,"\" cacls \"");
strcat(buffer,*locker_informal_path);
strcat(buffer,"\" /e /d everyone \"");


strcpy(lock_locker,buffer);

//cout<<"\n\n"<<unlock_locker;
system(lock_locker);
     

}












/*

``````````````````````````````````````````````````````````````````````````````````~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

void place_data_inside_locker_folder(char **locker_formal_path,char **temp_folder_path)
{
     

//copy /y temp_folder_path\*.* locker_formal_path\

char copy_files[2000];
char buffer[2000]="\" copy /y \"";

strcat(buffer,*temp_folder_path);
strcat(buffer,"\\*.*\" \"");
strcat(buffer,*locker_formal_path);
strcat(buffer,"\" \"");


strcpy(copy_files,buffer);
//cout<<"\n\n"<<copy_files;



system(copy_files);





//del /f /q temp_folder_path\*.*




// clean temp folder
}














