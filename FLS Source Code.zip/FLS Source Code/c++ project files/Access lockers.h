#define ACCESS_LOCKERS_H


//For Ecnryption/Decryption and for deleting duplicate files
void encrypt_or_decrypt(char **file_name);
void copy_files_inside_the_temp_folder(char **file_name,char **temp_folder_path);




//For Extraction of files
void extract_files(char **source,char **destination);
void delete_existing_files_inside_extraction_folder(char **source,char **destination);


//For Restoration of files
void restore_files_delete(char **locker_path,char **file_name_to_be_restored,char **file_path_to_be_restored);
void restore_files_copy(char **locker_path,char **file_name_to_be_restored,char **file_path_to_be_restored);
void restore_files_decrypt(char **locker_path,char **file_name_to_be_restored,char **file_path_to_be_restored);



//For Open,Close lockers and Place data inside lockers
void open_the_locker_folder(char **locker_formal_name,char **locker_informal_name,char **locker_origional_path,char **cacls_locker_informal_path);
void close_the_locker_folder(char **locker_formal_name,char **locker_informal_name,char **locker_origional_path,char **cacls_locker_informal_path);
void place_data_inside_locker_folder(char **locker_formal_path,char **temp_folder_path);
