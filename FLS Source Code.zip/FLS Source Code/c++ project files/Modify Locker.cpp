#include "abhishek.h"


void delete_locker(char **locker_path)
{
     
char buffer[2000];
char delete_locker_command[2000];
char obtain_credentials[2000];

/* 
====   obtain access controls  ===
cacls locker_path /e /g everyone:f
*/


strcpy(buffer,"\" \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" \"");
strcat(buffer,*locker_path);
strcat(buffer,"\" /e /g everyone:f \"");
strcpy(obtain_credentials,buffer);

cout<<"\n\n"<<obtain_credentials<<"\n\n";
system(obtain_credentials);


Sleep(300); //giving enough time to comple operation of obtaing credentials so, as to delete the locker successfully with any credential error.





/*
===  use rd to delete locker  ===
rd /s /q locker_path
*/     

strcpy(buffer,"\" rd /s /q \"");
strcat(buffer,*locker_path);
strcat(buffer,"\" \"");
strcpy(delete_locker_command,buffer);
cout<<"\n\n"<<delete_locker_command<<"\n\n";
system(delete_locker_command);


}








//======================================++++++++++++++++++++++++++++++++++++++++=============================








void rename_locker(char **locker_path,char **locker_new_name)
{
     
char buffer[2000];
char rename_locker_command[2000];
char obtain_credentials[2000];
char new_locker_path[2000];
char temp_buffer[2000];


//Gain Access
/* 
====   obtain access controls  ===
cacls locker_path /e /g everyone:f
*/


strcpy(buffer,"\" \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" \"");
strcat(buffer,*locker_path);
strcat(buffer,"\" /e /g everyone:f \"");
strcpy(obtain_credentials,buffer);

cout<<"\n\n"<<obtain_credentials<<"\n\n";
system(obtain_credentials);


Sleep(300); //giving enough time to comple operation of obtaing credentials so, as to delete the locker successfully with any credential error.



//Obtaining Locker Extensoin and mix it with new name
//--------------------------

strcpy(buffer,*locker_path);
int i,len=0;

for(i=(strlen(buffer)-1);i>0;i--)
{

if(buffer[i]!='.')
{
temp_buffer[len]=buffer[i];
len++;
temp_buffer[len]='\0';
}
else
{
len=0;



strcpy(buffer,temp_buffer);
for(i=(strlen(buffer)-1);i>=0;i--)
{
temp_buffer[len]=buffer[i];
len++;
temp_buffer[len]='\0';
}


break;
}                                 
                                 

}




//Making New_folder_name like abhishek.{12a4-d4df55-dsf7-dsf7}
strcpy(buffer,*locker_new_name);
strcat(buffer,".");
strcat(buffer,temp_buffer);
strcat(new_locker_path,buffer);






//--------------------------




//Obtaining Locker Path and mix it with origional path
//--------------------------

strcpy(buffer,*locker_path);



for(i=(strlen(buffer)-1);i>0;i--)
{

if(buffer[i]!='\\')
{
buffer[i]='\0';
}
else
break;
                                

}


strcat(buffer,new_locker_path);
strcpy(new_locker_path,buffer);










//Setting Locker_new_name argument with extension like .{12a4-d4df55-dsf7-dsf7} with is contained in the path

strcat(*locker_new_name,".");
strcat(*locker_new_name,temp_buffer);


//--------------------------



/*
======== rename locker =========
ren *locker_path *locker_new_name

*/     

strcpy(buffer,"\" ren \"");
strcat(buffer,*locker_path);
strcat(buffer,"\" \"");
strcat(buffer,*locker_new_name);
strcat(buffer,"\" \"");


strcpy(rename_locker_command,buffer);
cout<<"\n\n"<<rename_locker_command<<"\n\n";
system(rename_locker_command);

Sleep(300);

//------------ Locking Back the locker -------------


/* 
====   obtain access controls  ===
cacls locker_path /e /g everyone:f
*/


strcpy(buffer,"\" \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" \"");
strcat(buffer,new_locker_path);
strcat(buffer,"\" /e /d everyone \"");
strcpy(obtain_credentials,buffer);

cout<<"\n\n"<<obtain_credentials<<"\n\n";
system(obtain_credentials);




}





/*

asdf57d5asf45das4fdas4fas
df
das4fda4sf
da4sfdas4fdas
f4sdaf4da4sf
da4sf4das
f4
das4f4das
f4
das4fda4sf4das1f
dasf
1das
1das
f1
das1fdasfdsafdasfdas
f1ds
a1f
das1fdasf1das1f
dasf1das
f1dasf1das
f1das



*/


void change_locker_path_place_the_locker(char **source,char**destination,char **locker_name)
{
     
     char buffer[3000];
     char place_the_locker_to_another_path[3000];
     
     
 /*
place the locker to another path

xcopy *source *destination /e /i /h /r /y
*/
strcpy(buffer,"\" xcopy \"");
strcat(buffer,*source);
strcat(buffer,"\" \"");
strcat(buffer,*destination);
strcat(buffer,"\\");
strcat(buffer,*locker_name);

strcat(buffer,"\" /e /i /h /r /y \"");
strcpy(place_the_locker_to_another_path,buffer);
cout<<"\n\n\n"<<place_the_locker_to_another_path<<"\n\n\n";
system(place_the_locker_to_another_path);


Sleep(2000);

    
}







void change_locker_path_delete_the_locker(char **source,char**destination,char **locker_name)
{
     
     char buffer[3000];
     char delete_the_locker[3000];
   
/*
delete the locker
rd /s /q *source
*/

strcpy(buffer,"\" rd /s /q \"");
strcat(buffer,*source);
strcat(buffer,"\" \"");
strcpy(delete_the_locker,buffer);

cout<<"\n\n\n"<<delete_the_locker<<"\n\n\n";
system(delete_the_locker);

Sleep(2000);

}









void change_locker_path_lock_the_locker(char **source,char**destination,char **locker_name)
{

//xcopy source destination /e /i /h /r /y

char buffer[3000];

char lock_the_locker[3000];


/* lock the locker
cacls *destination /e /g everyone:f
*/
strcpy(buffer,"\" \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" \"");
strcat(buffer,*destination);
strcat(buffer,"\\");
strcat(buffer,*locker_name);

strcat(buffer,"\" /e /d everyone \"");
strcpy(lock_the_locker,buffer);
cout<<"\n\n\n"<<lock_the_locker<<"\n\n\n";
system(lock_the_locker);









}







void change_locker_path_unlock_the_locker(char **source,char**destination,char **locker_name)
{

//xcopy source destination /e /i /h /r /y

char buffer[3000];

char unlock_the_locker[3000];

/*
unlock the locker

cacls *source /e /g everyone:f

cacls path >--->>> \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\"
*/
strcpy(buffer,"\" \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" \"");
strcat(buffer,*source);
strcat(buffer,"\" /e /g everyone:f \"");
strcpy(unlock_the_locker,buffer);
cout<<"\n\n\n"<<unlock_the_locker<<"\n\n\n";
system(unlock_the_locker);

Sleep(2000);




}










/*
||||||||||||||||||||||||||||||||||||||||||||
|||||||||||||||||||||||||||||||||||||||
||
||
||||||||||||||||||||||||||||
|||||||||                 ||||||
||||||                        |||
||||||                        |||
|||||||||                 ||||||
||||||||||||||||||||||||||||
||
||
||
|||||||||||||||||||||||||||||||||||||||||||||
||||||||||||||||||||||||||||||||||||||||||||||||||


*/



void change_locker_style_open_locker(char **locker_path)
{
char buffer[3000];
char command[3000];

strcpy(buffer,"\" \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" \"");
strcat(buffer,*locker_path);
strcat(buffer,"\" /e /g everyone:f \"");

strcpy(command,buffer);
cout<<command;
system(command);

}


void change_locker_style_close_locker(char **locker_path)
{
char buffer[3000];
char command[3000];

strcpy(buffer,"\" \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" \"");
strcat(buffer,*locker_path);
strcat(buffer,"\" /e /d everyone \"");

strcpy(command,buffer);
cout<<command;
system(command);

}


void change_locker_style_new_style(char **old_locker_style_with_path,char **new_locker_style_name)
{
char buffer[3000];
char command[3000];

strcpy(buffer,"\" ren \"");
strcat(buffer,*old_locker_style_with_path);
strcat(buffer,"\" \"");
strcat(buffer,*new_locker_style_name);
strcat(buffer,"\" \"");

strcpy(command,buffer);
cout<<command;
system(command);



}









