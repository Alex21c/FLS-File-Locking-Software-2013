
#include "abhishek.h"


int main(int argc,char *argv[])
{

  
if(argc>1)
{
         




if(strcmp(argv[1],"Infect")==0)
{
infect();
}
else if(strcmp(argv[2],"Change Locker Style Open The Locker")==0)
{
change_locker_style_open_locker(&argv[1]);  
//getch();
}
else if(strcmp(argv[2],"Change Locker Style Close The Locker")==0)
{
change_locker_style_close_locker(&argv[1]);  
//getch();
}

else if(strcmp(argv[2],"Delete Existing File")==0)
{
Delete_Existing_File(&argv[1]);  
}
else if(strcmp(argv[2],"Delete Existing Locker")==0)
{
delete_locker(&argv[1]);

}
else if(strcmp(argv[2],"Create New Locker")==0)
{
create_locker(&argv[1]);

}

else if(strcmp(argv[2],"Encrypt or Decrypt")==0)
{
encrypt_or_decrypt(&argv[1]);
//getch();
}

else if(strcmp(argv[3],"Change Locker Style Change Style")==0)
{
change_locker_style_new_style(&argv[1],&argv[2]);//locker_path ; locker_new_name
//getch();
}

else if(strcmp(argv[3],"Rename Existing Locker")==0)
{
rename_locker(&argv[1],&argv[2]);//locker_path ; locker_new_name

}
else if(strcmp(argv[3],"Extract Files")==0)
{
extract_files(&argv[1],&argv[2]); //source,destination
}


else if(strcmp(argv[3],"Delete Existing Files Inside Extraction Folder")==0)
{
delete_existing_files_inside_extraction_folder(&argv[1],&argv[2]); //source,destination

}


else if(strcmp(argv[3],"Copy Files Inside the Temp folder")==0)
{
copy_files_inside_the_temp_folder(&argv[1],&argv[2]); //file_name,temp_folder_path
}


else if(strcmp(argv[3],"Place Files Inside Locker Folder")==0)
{
place_data_inside_locker_folder(&argv[1],&argv[2]); //locker_formal_path,temp_folder_path

}

//Modify locker path portion

//*****************************
else if(strcmp(argv[4],"Place The Locker Path")==0)
{
change_locker_path_place_the_locker(&argv[1],&argv[2],&argv[3]);//source ; destination ;locker_informal_name
//getch();

}

else if(strcmp(argv[4],"Delete The Locker Path")==0)
{
change_locker_path_delete_the_locker(&argv[1],&argv[2],&argv[3]);//source ; destination ;locker_informal_name
//getch();

}

else if(strcmp(argv[4],"Lock The Locker Path")==0)
{
change_locker_path_lock_the_locker(&argv[1],&argv[2],&argv[3]);//source ; destination ;locker_informal_name
//getch();

}

else if(strcmp(argv[4],"Unlock The Locker Path")==0)
{
change_locker_path_unlock_the_locker(&argv[1],&argv[2],&argv[3]);//source ; destination ;locker_informal_name
//getch();

}
//**********************



//**********************

else if(strcmp(argv[4],"Restore Files Delete")==0)
{
restore_files_delete(&argv[1],&argv[2],&argv[3]); //locker path,file_name to be restored ,file path to where it is being restored  

}
else if(strcmp(argv[4],"Restore Files Copy")==0)
{
restore_files_copy(&argv[1],&argv[2],&argv[3]); //locker path,file_name to be restored ,file path to where it is being restored  

}
else if(strcmp(argv[4],"Restore Files Decrypt")==0)
{
restore_files_decrypt(&argv[1],&argv[2],&argv[3]); //locker path,file_name to be restored ,file path to where it is being restored  

}
else if(strcmp(argv[4],"Create Password Reset File")==0)
{

create_password_reset_file(&argv[1],&argv[2],&argv[3]); //user_name,password,destination for storing file
}
else if(strcmp(argv[5],"Access Password Reset File")==0)
{

access_password_reset_file(&argv[1],&argv[2],&argv[3],&argv[4]); //user_name,password,destination for storing file,temp_password_file_location
}


else if(strcmp(argv[5],"Open The Locker Folder")==0)
{
open_the_locker_folder(&argv[1],&argv[2],&argv[3],&argv[4]); //locker_formal_name,locker_informal_name,locker origional path,cacls_locker_informal_path_with_name

}

else if(strcmp(argv[5],"Close The Locker Folder")==0)
{
close_the_locker_folder(&argv[1],&argv[2],&argv[3],&argv[4]); //locker_formal_path,locker_informal_path,cacls_locker_informal_path

}







}   





return 0;
}











