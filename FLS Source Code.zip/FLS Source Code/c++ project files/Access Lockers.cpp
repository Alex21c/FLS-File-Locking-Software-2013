#include "abhishek.h"



void encrypt_or_decrypt(char **file_name)
{





fstream music,temp5;
music.open(*file_name,ios::binary|ios::in|ios::ate);


bool error;

error=false;

if (music.is_open()==false) //error when opening file
{

error=true;


}


if (error==true)
{
cout<<"Error.";
exit(0);
}

music.close();

int size;
int i,len=0,;

//char  *file_path="C:\\Users\\Abhishek Kumar\\Desktop\\Kalimba.mp3";


char *temp_file_path;
char temp_buffer[5000];
char temp_buffer2[5000];





char extract[3000];
char delete_file[3000];

strcpy(temp_buffer,*file_name);

cout<<"\n\n\n";
cout<<temp_buffer;

//Obtain full path without the "\" i.e. backward slash


for(i=(strlen(temp_buffer)-1);i>0;i--)
{

if(temp_buffer[i]!='\\')
{
//temp_buffer2[len]=temp_buffer[i];
size=i;
//temp_buffer2[len]='\0';
}
else
{
size=size-1;
len=0;
for(i=0;i<=size;i++)
{

temp_buffer2[len]=temp_buffer[i];
len++;
temp_buffer2[len]='\0';
}


break;
}                                 
                                 

}




strcat(temp_buffer2,"anonymous.123");
cout<<"\n\n\n"<<temp_buffer2;




cout<<"\n\n"<<*file_name;



size=0;

music.open(*file_name,ios::binary|ios::in|ios::ate);


size=music.tellg();
music.seekg(ios::beg);



char *buffer;

buffer=new char[size];


//strcpy(buffer,"ASDFSDAFSDAFSADF");



music.read(buffer,size);


cout<<"\n\n"<<sizeof(buffer);



int key2=123;


for(i=0;i<size;i++)
{

//cout<<*buffer;
*buffer=*buffer^key2;
//cout<<"  "<<*buffer;
++buffer;
}

buffer-=size;

music.close();

music.open(*file_name,ios::binary|ios::out);



music.write(buffer,size);


music.close();




delete [] buffer;
}

/***************************************************************************/









void copy_files_inside_the_temp_folder(char **file_name,char **temp_folder_path)
{
   
   
   //takeown /f filename
   char takeown[2000]="\" takeown /f \"";
   strcat(takeown,*file_name);
   strcat(takeown,"\" \"");
   
   /*
   copy /y  source,destination
   /y -> overwrite confimation prompt of being files overwritten
   */
   char copy[2000]="\" copy /y \"";
   strcat(copy,*file_name);//source
   strcat(copy,"\" \"");
   strcat(copy,*temp_folder_path);//destination
   strcat(copy,"\" \"");
   
   // del /f /q file_name
   
   char del[2000]="\"del /f /q \"";
   strcat(del,*file_name);
   strcat(del,"\" \"");
   
  
   system(takeown);
   
   
   system(copy);
   
   system(del);
 
     
     
     
}






/***************************************************************************/







void open_the_locker_folder(char **locker_formal_name,char **locker_informal_name,char **locker_origional_path,char **cacls_locker_informal_name)
{
char buffer[2000];
char unlock_locker[2000];

strcpy(buffer,"\" \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\"  \""); 
strcat(buffer,*cacls_locker_informal_name);
strcat(buffer,"\" /e /g everyone:f \"");

strcpy(unlock_locker,buffer);

system(unlock_locker);





char rename_locker[2000];


//ren "*locker_informal_name" "*locker_formal_name"

/*
----------------changing the locker type to the formal locker type i.e renaming---------------

syntax:       
ren locker_file_name_with_extensoin locker_file_name_without_extensoin 
*/


strcpy(buffer,"\" ren \"");
strcat(buffer,*locker_origional_path);
strcat(buffer,"\\");
strcat(buffer,*locker_informal_name);
strcat(buffer,"\"  \"");

strcat(buffer,*locker_formal_name);
strcat(buffer,"\"  \"");




strcpy(rename_locker,buffer);



system(rename_locker);



cout<<"\n\n"<<rename_locker;
     

}

/*

``````````````````````````````````````````````````````````````````````````````````~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

void close_the_locker_folder(char **locker_formal_name,char **locker_informal_name,char **locker_origional_path,char **cacls_locker_informal_path)
{
     

char buffer[2000];
char rename_locker[2000];








//ren "*locker_informal_name" "*locker_formal_name"

/*
----------------changing the locker type to the formal locker type i.e renaming---------------

syntax:       
ren locker_file_name_with_extensoin locker_file_name_without_extensoin 
*/


strcpy(buffer,"\" ren \"");
strcat(buffer,*locker_origional_path);
strcat(buffer,"\\");
strcat(buffer,*locker_formal_name);
strcat(buffer,"\"  \"");

strcat(buffer,*locker_informal_name);
strcat(buffer,"\"  \"");


strcpy(rename_locker,buffer);

system(rename_locker);

cout<<"\n\n"<<rename_locker;




/*
----------------locking the locker i.e. changing access controls---------------

syntax:       
cacls file_name /e /g everyone:f

cacls "*locker_formal_name" /d everyone 

*/

char lock_locker[2000];
strcpy(buffer,"\" \"C:\\Windows\\System32\\spool\\drivers\\color\\cacls.exe\" \"");
strcat(buffer,*cacls_locker_informal_path);
strcat(buffer,"\" /e /d everyone \"");


strcpy(lock_locker,buffer);

cout<<"\n\n"<<lock_locker;
system(lock_locker);
     

}












/*

``````````````````````````````````````````````````````````````````````````````````~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

void place_data_inside_locker_folder(char **locker_formal_path,char **temp_folder_path)
{
     

//copy /y temp_folder_path\*.* locker_formal_path\


//************ copy files insie the locker *****************

char copy_files[2000];
char buffer[2000]="\" copy /y \"";

strcat(buffer,*temp_folder_path);
strcat(buffer,"\\*.*\" \"");
strcat(buffer,*locker_formal_path);
strcat(buffer,"\" \"");


strcpy(copy_files,buffer);
cout<<"\n\n"<<copy_files;
////cout<<"\n\n";


system(copy_files);



//**************** clean temp folder***************

char clean_temp_folder[2000];


//del /f /q temp_folder_path\*.*

strcpy(buffer, "\" del /f /q \"");
strcat(buffer,*temp_folder_path);
strcat(buffer,"\\*.*\" \"");

strcpy(clean_temp_folder,buffer);
cout<<"\n\n"<<clean_temp_folder;

system(clean_temp_folder);





}



void delete_existing_files_inside_extraction_folder(char **source,char **destination)
{
char buffer[3000];
char temp_buffer[2000];

char extract[3000];
char delete_file[3000];

strcpy(buffer,*source);

cout<<"\n\n\n";
cout<<buffer;

//Obtain full path without the "\" i.e. backward slash
int i,len=0;

for(i=(strlen(buffer)-1);i>0;i--)
{

if(buffer[i]!='\\')
{
temp_buffer[len]=buffer[i];
len++;
temp_buffer[len]='\0';
}
else
{
len=0;
strcpy(buffer,temp_buffer);
for(i=(strlen(buffer)-1);i>=0;i--)
{
temp_buffer[len]=buffer[i];
len++;
temp_buffer[len]='\0';
}


break;
}                                 
                                 

}


cout<<temp_buffer;
cout<<"\n\n"<<*destination;

strcpy(buffer,"\" del /f \"");
strcat(buffer,*destination);
strcat(buffer,"\\");
strcat(buffer,temp_buffer);
strcat(buffer,"\" \"");
strcpy(delete_file,buffer);
cout<<"\n\n File To Delete : "<<delete_file;

//cout<<"\n\n\n";
system(delete_file);


////getch();





}

void extract_files(char **source,char **destination)
{
     
char buffer[3000];

char extract[3000];



strcpy(buffer,"\"  copy /y \"");
strcat(buffer,*source);
strcat(buffer,"\"  \"");
strcat(buffer,*destination);
strcat(buffer,"\"  \"");


strcpy(extract,buffer);


system(extract);




     
}

//delete existing file
void restore_files_delete(char **locker_path,char **file_name_to_be_restored,char **file_path_to_be_restored)
{
char buffer[3000];
char delete_existing_file[3000];

//========================================================================================
/* ----------------- Delete Existing file ----------------
del c:\windows\system32\sample.png
*/

strcpy(buffer,"\" del /f /q  \"");
strcat(buffer,*file_path_to_be_restored);
strcat(buffer,"\\");
strcat(buffer,*file_name_to_be_restored);
strcat(buffer,"\"  \"");

strcpy(delete_existing_file,buffer);
cout<<"\n\n\n\n"<<delete_existing_file<<"\n\n\n";
system(delete_existing_file);
//========================================================================================


     
}

void restore_files_copy(char **locker_path,char **file_name_to_be_restored,char **file_path_to_be_restored)
{
char buffer[3000];
char copy_file_to_its_origional_location_back[3000];

  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*---------------------------- Copy -----------------------
copy c:\users\abhishek kumar\desktop\sample.png c:\windows\system32
*/
strcpy(buffer,"\" copy /y  \"");
strcat(buffer,*locker_path);
strcat(buffer,"\\");
strcat(buffer,*file_name_to_be_restored);
strcat(buffer,"\"  \"");
strcat(buffer,*file_path_to_be_restored);
strcat(buffer,"\" \"");

strcpy(copy_file_to_its_origional_location_back,buffer);
cout<<"\n\n\n\n"<<copy_file_to_its_origional_location_back<<"\n\n\n";
system(copy_file_to_its_origional_location_back);

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   
     
}


void restore_files_decrypt(char **locker_path,char **file_name_to_be_restored,char **file_path_to_be_restored)
{
char buffer[3000];
char decrypt_file_back[3000];


//c:\users\abhishek kumar\desktop  sample.png c:\windows\system32


/*---------------------- decrypt --------------------
c:\windows\system32\sample.png
*/

//##################################################################################################


strcpy(buffer,*file_path_to_be_restored);
strcat(buffer,"\\");
strcat(buffer,*file_name_to_be_restored);

strcpy(decrypt_file_back,buffer);

//system("cls");
cout<<"\n\n\n\n"<<decrypt_file_back<<"\n\n\n";




char *pbuffer;

pbuffer=buffer;

encrypt_or_decrypt(&pbuffer);


//##################################################################################################


}






