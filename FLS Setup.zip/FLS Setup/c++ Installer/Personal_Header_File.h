#define PERSONAL_HEADER_FILE_H



//Functions Regarded to Registry
void add_uninstaller_to_registry(char **uninstaller_icon,char **uninstaller_file);
void remove_uninstaller_from_registry();


//Functions Related To Dll Files
void register_dll_files();
void unregister_dll_files();

//Functions for copying Files
void copy_buffer_folder_files(char **source);
void copy_main_folder_files(char **source,char **destination);
void copy_Dll_folder_files(char **source);


//Functions Related to clearing Files
void  delete_all_files(char **destination);


//Functions related to Creating Shortcut
void create_shortcut(char **make_vbs_file_location,char **launcher_file_location,char **shortcut_destination);

//Functions related to Creating Shortcut
void create_StartMenu_shortcut(char **make_vbs_file_location,char **launcher_file_location,char **uninstaller_file_location,char **shortcut_destination);

//For Restarting Explorer
void restart_explorer();


//Functions Related To Installation of Fonts
void install_fonts(char **font_source,char **registry_value,char **registry_data);


//Function related to uninstallation
void delete_all_shortcuts_including_registry_uninstaller(char **desktop_shortcut_destination,char **StartMenu_shortcut_destination);



