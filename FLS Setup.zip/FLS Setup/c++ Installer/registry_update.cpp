#include "abhishek.h"


void remove_uninstaller_from_registry()
{
char buffer[3000];
strcpy(buffer,"reg delete \"hklm\\software\\microsoft\\windows\\currentversion\\uninstall\\File Locking Software\" /f");
system (buffer);
//cout<<"\n\n"<<buffer<<"\n\n";

}



void add_uninstaller_to_registry(char **uninstaller_icon,char **uninstaller_file)
{
char buffer[3000];


strcpy(buffer,"reg add \"hklm\\software\\microsoft\\windows\\currentversion\\uninstall\\File Locking Software\" /v \"DisplayName\" /t REG_SZ /d \"File Locking Software\" /f");
system (buffer);
//cout<<"\n\n"<<buffer<<"\n\n";


strcpy(buffer,"reg add \"hklm\\software\\microsoft\\windows\\currentversion\\uninstall\\File Locking Software\" /v \"DisplayVersion\" /t REG_SZ /d \"1.0.0\" /f");
system (buffer);
//cout<<"\n\n"<<buffer<<"\n\n";

strcpy(buffer,"reg add \"hklm\\software\\microsoft\\windows\\currentversion\\uninstall\\File Locking Software\" /v \"Publisher\" /t REG_SZ /d \"Anonymous\" /f");
system (buffer);
//cout<<"\n\n"<<buffer<<"\n\n";



//==============-------------============ Estimated Size ========---------================

strcpy(buffer,"reg add \"hklm\\software\\microsoft\\windows\\currentversion\\uninstall\\File Locking Software\" /v \"EstimatedSize\" /t REG_DWORD /d \"27000\" /f");
system (buffer);
//cout<<"\n\n"<<buffer<<"\n\n";



//================================-------------------===================----------------------=========


strcpy(buffer,"reg add \"hklm\\software\\microsoft\\windows\\currentversion\\uninstall\\File Locking Software\" /v \"NoModify\" /t REG_DWORD /d \"1\" /f");
system (buffer);
//cout<<"\n\n"<<buffer<<"\n\n";

strcpy(buffer,"reg add \"hklm\\software\\microsoft\\windows\\currentversion\\uninstall\\File Locking Software\" /v \"NoRepair\" /t REG_DWORD /d \"1\" /f");
system (buffer);
//cout<<"\n\n"<<buffer<<"\n\n";


strcpy(buffer,"reg add \"hklm\\software\\microsoft\\windows\\currentversion\\uninstall\\File Locking Software\" /v \"DisplayIcon\" /t REG_SZ /d \"");
strcat(buffer,*uninstaller_icon);
strcat(buffer,"\" /f");
system (buffer);
//cout<<"\n\n"<<buffer<<"\n\n";


strcpy(buffer,"reg add \"hklm\\software\\microsoft\\windows\\currentversion\\uninstall\\File Locking Software\" /v \"UninstallString\" /t REG_SZ /d \"\\\"");
strcat(buffer,*uninstaller_file);
strcat(buffer,"\\\"\" /f");
system (buffer);
cout<<"\n\n"<<buffer<<"\n\n";
//getch();
     
//--> Registry with quotes \"Abhi\"  -> "Abhi" 
}





void register_dll_files()
{

system ("regsvr32 /s  C:\\WINDOWS\\system32\\comdlg32.ocx");
system ("regsvr32 /s  C:\\WINDOWS\\system32\\MSRD2X35.DLL");
system ("regsvr32 /s  C:\\WINDOWS\\system32\\MSJET35.DLL");
system ("regsvr32 /s \"C:\\Program Files\\Common Files\\Microsoft Shared\\DAO\\DAO350.DLL\"");
system ("regsvr32 /s \"C:\\WINDOWS\\system32\\comdlg32.ocx\"");   



}

void unregister_dll_files()
{
system ("regsvr32 -u /s  C:\\WINDOWS\\system32\\comdlg32.ocx");
system ("regsvr32 -u /s  C:\\WINDOWS\\system32\\MSRD2X35.DLL");
system ("regsvr32 -u /s  C:\\WINDOWS\\system32\\MSJET35.DLL");
system ("regsvr32 -u /s \"C:\\Program Files\\Common Files\\Microsoft Shared\\DAO\\DAO350.DLL\"");
system ("regsvr32 -u /s \"C:\\WINDOWS\\system32\\comdlg32.ocx\"");   
    
}







void install_fonts(char **font_source,char **registry_value,char **registry_data)
{
system("@echo off");
     
char buffer[3000];


//Copying Font
strcpy(buffer,"\" copy /y \"");
strcat(buffer,*font_source);

strcat(buffer,"\" \"%systemroot%\\fonts\"");

//strcat(buffer,"\" \"%systemroot%\"");


strcat(buffer,"  \"");

cout<<"\n\n\n\n"<<buffer<<"\n\n";
system(buffer);

//-------============= Registering Font ==========--------


strcpy(buffer,"\" reg add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Fonts\" /v \"");
strcat(buffer,*registry_value);
strcat(buffer,"\" /t REG_SZ /d \"");
strcat(buffer,*registry_data);
strcat(buffer,"\" /f \"");


cout<<"\n\n\n\n"<<buffer<<"\n\n";
system(buffer);



     
     
}











